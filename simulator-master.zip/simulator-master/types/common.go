package types

// ID represents unique id
type ID int64
