package net

// Address represents network address
type Address interface{}
